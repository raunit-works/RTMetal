'use client';

import * as React from 'react';
import {
  AlertCircle,
  Check,
  ChevronDown,
  ChevronUp,
  ImageOff,
  Loader2,
  Plus,
  Trash2,
  Upload,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { uploadCatalogImage } from '@/lib/supabase/admin-catalog';
import {
  createVariantAdmin,
  deleteVariantAdmin,
  ensureFinishOptionAdmin,
  getProductVariantsAdmin,
  linkVariantOptionAdmin,
  reorderVariantsAdmin,
  saveVariantOptionValueAdmin,
  setDefaultVariantAdmin,
  syncVariantImagesAdmin,
  updateVariantAdmin,
} from '@/lib/supabase/product-variants-admin';
import {
  getImageErrorMessage,
  prepareImageUpload,
} from '@/lib/images/prepare-image-upload';
import type {
  ProductVariantImage,
  SwatchType,
  VariantAvailability,
} from '@/lib/types';

interface VariantImageDraft extends ProductVariantImage {
  key: string;
}

interface VariantUploadStatus {
  id: string;
  fileName: string;
  status: 'uploading' | 'error';
  message?: string;
}

interface VariantDraft {
  key: string;
  id?: string;
  optionValueId?: string;
  finishName: string;
  swatchType: SwatchType;
  swatchColor1: string;
  swatchColor2: string;
  swatchImageUrl: string;
  sku: string;
  stockQuantity: string;
  availability: VariantAvailability;
  isActive: boolean;
  isDefault: boolean;
  images: VariantImageDraft[];
  removedImageIds: string[];
  uploads: VariantUploadStatus[];
}

interface VariantBaseline {
  id: string;
  optionValueId?: string;
  finishName: string;
  swatchType: SwatchType;
  swatchColor1: string;
  swatchColor2: string;
  swatchImageUrl: string;
  sku: string;
  stockQuantity: string;
  availability: VariantAvailability;
  isActive: boolean;
  isDefault: boolean;
  images: ProductVariantImage[];
}

export interface ProductVariantsEditorHandle {
  validate: () => { banner: string | null; fields: FieldValidationError[] };
  sync: (productId: string) => Promise<string[]>;
  reset: () => void;
  isDirty: () => boolean;
}

export interface FieldValidationError {
  key: string;
  field: 'finishName' | 'sku' | 'swatchColor1' | 'swatchColor2' | 'swatchImageUrl' | 'stockQuantity';
  message: string;
}

export const ProductVariantsEditor = React.forwardRef<
  ProductVariantsEditorHandle,
  ProductVariantsEditorProps
>(function ProductVariantsEditor({ productId }, ref) {
  const [enabled, setEnabled] = React.useState(false);
  const [variants, setVariants] = React.useState([]);

  React.useImperativeHandle(ref, () => ({
    validate: () => ({ banner: null, fields: [] }),
    isDirty: () => false,
    reset: () => {},
    sync: async () => [],
  }));

  return null;
});

interface ProductVariantsEditorProps {
  productId: string | null;
}

const DEFAULT_SWATCH_COLOR = '#C9A96E';

let draftCounter = 0;

function createDraftKey() {
  draftCounter += 1;
  return `new-${Date.now()}-${draftCounter}`;
}

function createEmptyDraft(displayOrder: number, isDefault: boolean): VariantDraft {
  return {
    key: createDraftKey(),
    finishName: '',
    swatchType: 'solid',
    swatchColor1: DEFAULT_SWATCH_COLOR,
    swatchColor2: '',
    swatchImageUrl: '',
    sku: '',
    stockQuantity: '',
    availability: 'in_stock',
    isActive: true,
    isDefault,
    images: [],
    removedImageIds: [],
    uploads: [],
  };
}

function mapDraftImage(image: ProductVariantImage): VariantImageDraft {
  return { ...image, key: image.id };
}

function draftPayload(draft: VariantDraft) {
  return {
    finishName: draft.finishName.trim(),
    swatchType: draft.swatchType,
    swatchColor1: draft.swatchColor1,
    swatchColor2: draft.swatchColor2,
    swatchImageUrl: draft.swatchImageUrl,
    sku: draft.sku.trim(),
    stockQuantity: draft.stockQuantity,
    availability: draft.availability,
    isActive: draft.isActive,
    isDefault: draft.isDefault,
    images: draft.images.map((image) => ({
      id: image.id,
      imageUrl: image.imageUrl,
      altText: image.altText ?? '',
      sortOrder: image.sortOrder,
      isPrimary: image.isPrimary,
    })),
  };
}

function signature(drafts: VariantDraft[]) {
  return JSON.stringify(
    drafts.map((draft) => ({ id: draft.id ?? null, ...draftPayload(draft) }))
  );
}

function normalizeHex(value: string, fallback: string): string {
  const trimmed = value.trim();
  return /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(trimmed) ? trimmed : fallback;
}

function availabilityLabel(value: VariantAvailability) {
  if (value === 'made_to_order') return 'Made to order';
  if (value === 'out_of_stock') return 'Unavailable';
  return 'In stock';
}